CREATE DATABASE actividad_3;

use actividad_3;

create table Usuario (
id_usuario int primary key,
nombre varchar(50) not null,
apellido varchar (50) not null,
telefono varchar (10),
email varchar(100) not null
);

create table Producto (
id_producto int primary key,
nomb_producto varchar(100) not null,
precio decimal (5.2) not null
);

INSERT INTO Usuario (id_usuario, nombre, apellido, email, telefono) VALUES
(1,'Juan', 'Pérez', 'juan.perez@gamil.com', '123456789'),
(2,'Ana', 'García', 'ana.garcia@gmail.com', '987654321'),
(3,'Luis', 'Martínez', 'luis.martinez@gmail.com', '2473019865'),
(4,'María', 'López', 'maria.lopez@gmail.com', '0951368702'),
(5,'Pedro', 'Alcivar', 'pedro.alcivar@gmail.com', '1762947381');


select nombre, apellido, telefono, email from Usuario;



