// Usuario.php
<?php
use Restserver\Libraries\REST_Controller;

class Usuario extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Usuario_model');
        $this->load->helper('url_helper');
    }

    public function index() {
        $data['usuarios'] = $this->Usuario_model->obtener_usuarios();
        echo json_encode($data);
    }

    public function view($id) {
        $data['usuario'] = $this->Usuario_model->obtener_usuario($id);
        echo json_encode($data);
    }

    public function create() {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->Usuario_model->crear_usuario($data);
        echo json_encode(array('status' => 'Usuario creado'));
    }
}


