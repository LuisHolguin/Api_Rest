<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Home extends BaseController
{
    public function index()
    {
        // Conectar a la base de datos
        $db = \Config\Database::connect();

        // Ejecutar la consulta
        $query = $db->query('SELECT nombre, apellido, telefono, email FROM usuarios');

        // Obtener los resultados
        $valor = $query->getResult();

        // Devolver los resultados en formato JSON
        return $this->response->setJSON($valor);
    }
}

