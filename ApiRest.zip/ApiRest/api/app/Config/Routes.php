<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Router\RouteCollection;

$routes = Services::routes();


if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}


$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);


$routes->get('/', 'Home::index');
$routes->get('/hola', 'Home::index');

// Rutas para usuarios
$routes->get('usuarios', 'Usuarios::index');
$routes->get('usuarios/(:num)', 'Usuarios::view/$1');
$routes->post('usuarios/create', 'Usuarios::create');

// Rutas para productos
$routes->get('productos', 'Productos::index');
$routes->get('productos/(:num)', 'Productos::view/$1');
$routes->post('productos/create', 'Productos::create');


if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}

